/*
 * @file systick.c
 * @brief
 *
 * This file provides functions for initializing the Systick timer and other timing APIs
 *
 * @date 07-Oct-2022
 * @author Anuhya
 */

#include <stdio.h>
#include "board.h"
#include "peripherals.h"
#include "pin_mux.h"
#include "clock_config.h"
#include "MKL25Z4.h"
#include "fsl_debug_console.h"
#include "core_cm0plus.h"

#include "systick.h"

uint32_t transition_time=0;							//counter for state transitions
uint32_t poll_time=0;								//counter for polling touch slider
uint32_t total_time=0;								//counter for total time since start


void init_systick()  {
	SysTick->LOAD = PERIOD-1;						//setting reload value to get 10ms interrupt
	SysTick->VAL=0;									//force load of reload value
	NVIC_SetPriority(SysTick_IRQn,3);				//set interrupt priority
	SysTick->CTRL = SysTick_CTRL_TICKINT_Msk 		//timer control and status register
					| SysTick_CTRL_CLKSOURCE_Msk
					| SysTick_CTRL_ENABLE_Msk;		//48MHz clock cource
}

void SysTick_Handler()  {
	total_time++;
	poll_time++;
	transition_time++;
}


uint32_t now() {
	return (total_time*10);
}


void reset_timer(){
	transition_time=0;
}

uint32_t get_timer(){
	return transition_time;
}

void reset_poll_timer(){
	poll_time=0;
}

uint32_t poll_timer(){
	return poll_time;
}



