/*
 * @file log.h
 * @brief
 *
 * This header file declares the run times in debug and production mode
 *
 * @date 07-Oct-2022
 * @author Anuhya
 */

#ifndef LOG_H_
#define LOG_H_

#ifdef DEBUG
#define LOG PRINTF
#define TIMEOUT (500)
#define T_WARNING (300)
#else
#define TIMEOUT (2000)
#define T_WARNING (500)
#define LOG(...)
#endif

#endif /* LOG_H_ */
