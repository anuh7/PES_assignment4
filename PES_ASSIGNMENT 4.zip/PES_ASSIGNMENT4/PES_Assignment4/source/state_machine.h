/*
 * @state_machine.c
 * @brief
 *
 * This header file declares functions for the state machine and LED colour transition
 *
 * @date 07-Oct-2022
 * @author Anuhya
 * @attributions: elevator2.c distributed in class
 */

#ifndef STATE_MACHINE_H_
#define STATE_MACHINE_H_


#define STOP_RED (97)
#define STOP_GREEN (30)
#define STOP_BLUE (60)
#define GO_RED (34)
#define GO_GREEN (150)
#define GO_BLUE (34)
#define WARNING_RED (255)
#define WARNING_GREEN (178)
#define WARNING_BLUE (0)
#define CROSSWALK_RED (0)
#define CROSSWALK_GREEN (16)
#define CROSSWALK_BLUE (48)
#define TRANSITION (100)
#define CROSSWALK_OFF (25)
#define CROSSWALK_ON (75)


/**
 * @brief Initializes the state machine
 * The function checks which state it is in; it updates LEDs values and the next state values
 * In every state, it is checked if the CROSSWALK state has been called
 * @return void.
 */
void state_machine();

/**
 * @brief Outputs the required LED values
 * The function decides the colour transition values based on the input and output colours given and passes it to the
 * CnV registers of all 3 channels. It checks if the touch slider has been pressed every 50ms.
 *
 * @param  nr Value of the red LED at the starting of transition
 * @param  ng Value of the green LED at the starting of transition
 * @param  nb Value of the blue LED at the starting of transition
 * @param  er Value of the red LED at the starting of transition
 * @param  eg Value of the green LED at the starting of transition
 * @param  eb Value of the blue LED at the starting of transition
 * @param  n Declares how long the transition is going occur
 * @return void.
 */
void colour_transition(int nr, int ng, int nb, int er, int eg, int eb, int n);


#endif /* STATE_MACHINE_H_ */
