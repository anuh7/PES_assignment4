/*
 * @file pwm_init.h
 * @brief
 *
 * This header file declares the initialization functions
 *
 * @date 07-Oct-2022
 * @author Anuhya
 */


#ifndef PWM_INIT_H_
#define PWM_INIT_H_

#define MOD_VALUE (1020)
/**
 * @brief Initializes the registers for PWM
 * In this function, the LEDs and timer peripherals registers are initialized for PWM;
 * The TPM2 Channel 0 controls the red LED
 * The TPM2 Channel 1 controls the green LED
 * The TPM0 Channel 1 controls the blue LED
 * @return void.
 */
void Init_PWM();

/**
 * @brief Initializes the touch sensor
 * The function provides clock gating to TSI module and sets the bits in TSI control and status register
 * @return void.
 */
void Touch_Init();

/**
 * @brief Calculates the touch sensor value
 * The function takes value from the DATA register and resets the scan flag.
 * @return returns touch sensor value with an offset.
 */
int Touch_Scan_LH();

#endif /* PWM_INIT_H_ */
