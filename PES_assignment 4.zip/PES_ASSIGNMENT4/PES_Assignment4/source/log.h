/*
 * log.h
 *
 *  Created on: 09-Oct-2022
 *      Author: ROTODYNE
 */

#ifndef LOG_H_
#define LOG_H_

#ifdef DEBUG
#define LOG PRINTF
#define DEBUG_TIMEOUT (500)
#define DEBUG_WARNING (300)
#else
#define DEBUG_TIMEOUT (2000)
#define DEBUG_WARNING (500)
#define LOG(...)
#endif

#endif /* LOG_H_ */
