/*
 * @state_machine.c
 * @brief
 *
 * This file provides functions for the state machine and LED colour transition
 *
 * @date 07-Oct-2022
 * @author Anuhya
 * @attributions: elevator2.c distributed in class
 */


#include <stdio.h>
#include "board.h"
#include "peripherals.h"
#include "pin_mux.h"
#include "clock_config.h"
#include "MKL25Z4.h"
#include "fsl_debug_console.h"
#include "core_cm0plus.h"


#include "systick.h"
#include "pwm_init.h"
#include "state_machine.h"
#include "log.h"
#include "pwm_init.h"


float now_r;						//current state LED values
float now_b;
float now_g;
float end_r;						//next state LED values
float end_g;
float end_b;
int n;								//timer constant
float present_r;					//transition LED values
float present_b;
float present_g;
int count=0;						//crosswalk loop counter
uint32_t pct=0;						//transition constant


/* listing out all the states */
typedef enum{
	STOP,
	GO,
	WARNING,
	CROSSWALK,
	STOP_GO,
	GO_WARNING,
	WARNING_STOP,
}states_t;

/* Struct to define current state */
static struct{
	states_t state;
} traffic_light={
	.state= STOP
};


void state_machine(){
	switch (traffic_light.state){																//checks the current state
	case STOP:
			LOG("State in STOP - %d msec since startup\n \r",now());
			colour_transition(STOP_RED, STOP_GREEN, STOP_BLUE, 0, 0, 0, DEBUG_TIMEOUT);			//input the STOP state rgb LED values
			if (traffic_light.state==CROSSWALK){												//check if in crosswalk state
				LOG("State change from STOP to CROSSWALK %d msec since startup\n \r",now());
				break;}
			traffic_light.state=STOP_GO;
	break;

	case STOP_GO:
			LOG("State change from STOP to GO - %d msec since startup\n \r",now());
			colour_transition(STOP_RED, STOP_GREEN, STOP_BLUE, GO_RED, GO_GREEN, GO_BLUE, TRANSITION);	//input state transition values from stop to go
			if (traffic_light.state==CROSSWALK){														//check if in crosswalk state
				LOG("State change from STOP_GO to CROSSWALK %d msec since startup\n \r",now());
				break;}
			traffic_light.state=GO;
	break;

	case GO:
			LOG("State in GO - %d msec since startup\n \r",now());
			colour_transition(GO_RED, GO_GREEN, GO_BLUE, 0, 0, 0, DEBUG_TIMEOUT);				//input GO state rgb LED values
			if (traffic_light.state==CROSSWALK){												//check if in crosswalk state
				LOG("State change from GO to CROSSWALK %d msec since startup\n \r",now());
				break;}
			traffic_light.state=GO_WARNING;
	break;

	case GO_WARNING:
			LOG("State change from GO to WARNING - %d msec since startup\n \r",now());
			colour_transition(GO_RED, GO_GREEN, GO_BLUE, WARNING_RED, WARNING_GREEN, WARNING_BLUE, TRANSITION);		//input state transition values from GO to WARNING
			if (traffic_light.state==CROSSWALK){																	//check if in crosswalk state
				LOG("State change from GO_WARNING to CROSSWALK %d msec since startup\n \r",now());
				break;}
			traffic_light.state=WARNING;
	break;

	case WARNING:
			LOG("State in WARNING - %d msec since startup\n \r",now());
			colour_transition(WARNING_RED, WARNING_GREEN, WARNING_BLUE, 0, 0, 0, DEBUG_WARNING);		//input WARNING state rgb LED values
			if (traffic_light.state==CROSSWALK){														//check if in crosswalk state
				LOG("State change from WARNING to CROSSWALK %d msec since startup\n \r",now());
				break;}
			traffic_light.state=WARNING_STOP;
	break;

	case WARNING_STOP:
			LOG("State change from WARNING to STOP - %d msec since startup\n \r",now());
			colour_transition(WARNING_RED, WARNING_GREEN, WARNING_BLUE, STOP_RED, STOP_GREEN, STOP_BLUE, TRANSITION);		//input state transition values from GO to WARNING
			if (traffic_light.state==CROSSWALK){																			//check if in crosswalk state
				LOG("State change from WARNING_STOP to CROSSWALK %d msec since startup\n \r",now());
					break;}
			traffic_light.state=STOP;
	break;

	case CROSSWALK:
			LOG("Button pressed - %d msec since startup\n \r",now());
			colour_transition(present_r, present_g, present_b, CROSSWALK_RED, CROSSWALK_GREEN, CROSSWALK_BLUE, TRANSITION);		//input current rgb values and CROSSWALK rgb values for state transition
			LOG("State in CROSSWALK - %d msec since startup\n \r",now());
			for (count=0; count<10; count++){																					//loop runs for 10s and blinks LED 10 times for CROSSWALK state
				colour_transition(0, 0, 0, 0, 0, 0, CROSSWALK_OFF);																//LEDs are off for 250ms
				colour_transition(CROSSWALK_RED, CROSSWALK_GREEN, CROSSWALK_BLUE, 0, 0, 0, CROSSWALK_ON);						//LEDs are on in CROSSWALK colours for 750ms
			}
			LOG("State change from CROSSWALK to GO - %d msec since startup\n \r",now());
			colour_transition(CROSSWALK_RED, CROSSWALK_GREEN, CROSSWALK_BLUE, GO_RED, GO_GREEN, GO_BLUE, TRANSITION);			//state transition from CROSSWALK to GO
			traffic_light.state=GO;
	break;
	}
}


void colour_transition(float now_r, float now_g, float now_b, float end_r, float end_g, float end_b, int n){
	if (end_r==0 && end_g==0 && end_b==0)											//check if state transition is occurring and update CnV accordingly
	 {
		while(get_timer()<n){														//run while transition time is not over
			if (poll_timer()>=5 && traffic_light.state!=CROSSWALK){					//poll touch slider every 50ms and if not in CROSSWALK state already
				reset_poll_timer();													//reset poll time
				if (Touch_Scan_LH()>=75){											//if touch slider value is greater than 75 update state
					traffic_light.state=CROSSWALK;									//update state value to CROSSWALK
					n=0; 															//clear timer values
					reset_timer();
					return;
				}}
			present_r=now_r;														//only one value for non-transition states
			present_b=now_b;
			present_g=now_g;
	        TPM2->CONTROLS[0].CnV = (present_r*(MOD_VALUE/255));							//update CnV register with LED values scaled to meet MOD register values
	        TPM0->CONTROLS[1].CnV = (present_b*(MOD_VALUE/255));							//TPM0_CH1 controls blue LED
	        TPM2->CONTROLS[1].CnV = (present_g*(MOD_VALUE/255));							//TPM2_CH1 controls green LED, TPM2_CH0 controls red LED
		}
	  n=0;
	  reset_timer();																//reset transition time
	}
	else{
		while(get_timer()<n){														//run while transtion time is not over
			if (poll_timer()>=5 && traffic_light.state!=CROSSWALK){					//poll every 50ms and if not in CROSSWALK state already
					reset_poll_timer();												//update poll time
					if (Touch_Scan_LH()>=75){										//if touch slider value is greater than 75 update state
							traffic_light.state=CROSSWALK;							//update state value to CROSSWALK
							n=0; 													//clear timer values
							reset_timer();											//reset transition time
							return;
					}}
			pct=get_timer();														//pct is updated with transition counter
			present_r= ((end_r-now_r)*(pct/100))+now_r;								//update present LED values every 10ms as trans variable increments every 10ms
			present_b= ((end_b-now_b)*(pct/100))+now_b;
			present_g= ((end_g-now_g)*(pct/100))+now_g;
			TPM2->CONTROLS[0].CnV = (present_r*(MOD_VALUE/255));					//update CnV register with LED values scaled to meet MOD register values
			TPM0->CONTROLS[1].CnV = (present_b*(MOD_VALUE/255));					//TPM0_CH1 controls blue LED
			TPM2->CONTROLS[1].CnV = (present_g*(MOD_VALUE/255));					//TPM2_CH1 controls green LED, TPM2_CH0 controls red LED
	    }
		n=0;																		//clear timer values
		reset_timer();																//reset transition time
	}
	return;
}



