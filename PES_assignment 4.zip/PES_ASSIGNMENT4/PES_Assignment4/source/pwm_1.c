/*
 * @file pwm_1.c
 * @brief
 *
 * This file calls the initializes functions and runs the state machine continuously
 *
 * @date 07-Oct-2022
 * @author Anuhya
 */

#include <stdio.h>
#include "board.h"
#include "peripherals.h"
#include "pin_mux.h"
#include "clock_config.h"
#include "MKL25Z4.h"
#include "fsl_debug_console.h"
#include "core_cm0plus.h"


/* TODO: insert other include files here. */
#include "systick.h"
#include "pwm_init.h"
#include "state_machine.h"
#include "log.h"

/* TODO: insert other definitions and declarations here. */  //daanish

/*
 * @brief   Application entry point.
 */
int main(void) {



    /* Init board hardware. */
    BOARD_InitBootPins();
    BOARD_InitBootClocks();
    BOARD_InitBootPeripherals();
#ifndef BOARD_INIT_DEBUG_CONSOLE_PERIPHERAL
    /* Init FSL debug console. */
    BOARD_InitDebugConsole();
#endif

    Init_PWM();
    init_systick();
    Touch_Init();
    LOG("main loop is starting now %d \n \r", now());
    while(1) {
    	state_machine();
    }
    return 0 ;
}
