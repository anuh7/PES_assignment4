/*
 * @file systick.h
 * @brief
 *
 * This header file provides functions for initializing the Systick timer and other timing APIs
 *
 * @date 07-Oct-2022
 * @author Anuhya
 */

#ifndef SYSTICK_H_
#define SYSTICK_H_

#define PERIOD (480000)
/**
 * @brief Initializes SysTick timer for interrupts of 10ms
 * For interrupt period of 10ms, the frequency=100Hz
 * Using processor clock=48MHz, load value=[(clk. freq/ req. freq)-1]
 * @return void.
 */
void init_systick();

/**
 * @brief Exception handler for SysTick Timer
 * Calculates global variables required in the main code
 * @return void.
 */
void SysTick_Handler();

/**
 * @brief Calculates the time since start-up
 * @return total_time
 */
uint32_t now();

/**
 * @brief Resets the transition counter
 * @return void
 */
void reset_timer();


/**
 * @brief Returns the transition counter value
 */
uint32_t get_timer();


/**
 * @brief Resets the poll time count
 * @return void
 */
void reset_poll_timer();


/**
 * @brief Returns the poll time counter
 * @return void
 */
uint32_t poll_timer();


#endif /* SYSTICK_H_ */
