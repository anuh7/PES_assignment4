/*
 * @file pwm_init.c
 * @brief
 *
 * This file initializes the capacitive touch sensor, calculates the touch sensor value
 * and initializes the timer/pwm modules of red, green, blue LEDs
 *
 * @date 07-Oct-2022
 * @author Anuhya
 * @attributions: https://github.com/alexander-g-dean/ESF/tree/master/NXP/Code/Chapter_7/PWM_LED
 * 				  https://github.com/alexander-g-dean/ESF/tree/master/NXP/Misc/Touch%20Sense
 */

#include <stdio.h>
#include "board.h"
#include "peripherals.h"
#include "pin_mux.h"
#include "clock_config.h"
#include "MKL25Z4.h"
#include "fsl_debug_console.h"
#include "core_cm0plus.h"

#include "pwm_init.h"


void Touch_Init()
{

	SIM->SCGC5 |= SIM_SCGC5_TSI_MASK;				//clock gating for TSI

	TSI0->GENCS = TSI_GENCS_MODE(0u) |							// 0 for capacitive sensing
								TSI_GENCS_REFCHRG(0u) |   		//oscillator charge= 500nA
								TSI_GENCS_DVOLT(0u) |			//0-3
								TSI_GENCS_EXTCHRG(0u) |			//oscillator voltage value
								TSI_GENCS_PS(0u) |				//freq divisor=1
								TSI_GENCS_NSCN(31u) |			//no. of scans per electrode
								TSI_GENCS_TSIEN_MASK |			//TSI enable bit
								TSI_GENCS_STPE_MASK | 			//enables TSI in low power mode
								TSI_GENCS_EOSF_MASK ;			//1 to clear the scan flag

}


int Touch_Scan_LH()											//reads touch sensor from low to high capacitance for left to right
{
	unsigned int scan=0;
	TSI0->DATA = 	TSI_DATA_TSICH(10u);						//using channel  10 of the TSI
	TSI0->DATA |= TSI_DATA_SWTS_MASK;							//trigger to start scanning
	while(!(TSI0->GENCS & TSI_GENCS_EOSF_MASK)) //wait for 32 scans i.e. until end of scan flag is not set
		__asm volatile("nop");
	scan = TSI0->DATA & TSI_DATA_TSICNT_MASK;					//accessing bits in the data register
	TSI0->GENCS |= TSI_GENCS_EOSF_MASK ;						//reset scan flag
    return (scan - 560);										//TSI has offset value of 560 //daanish
}



void Init_PWM(){

	SIM->SCGC5 |= SIM_SCGC5_PORTB_MASK | SIM_SCGC5_PORTD_MASK;			//clock gating to the ports B&D
	PORTB->PCR[BOARD_LED_RED_GPIO_PIN] &= ~(PORT_PCR_MUX_MASK);			//setting pin to FTM
	PORTB->PCR[BOARD_LED_RED_GPIO_PIN] |= PORT_PCR_MUX(3);				//Red FTM2_CH0, Mux Alt 3

	PORTB->PCR[BOARD_LED_GREEN_GPIO_PIN] &= ~(PORT_PCR_MUX_MASK);		//setting pin to FTM
	PORTB->PCR[BOARD_LED_GREEN_GPIO_PIN] |= PORT_PCR_MUX(3);			//Green TPM2_CH1, Mux Alt 3

	PORTD->PCR[BOARD_LED_BLUE_GPIO_PIN] &= ~(PORT_PCR_MUX_MASK);		//setting pin to FTM
	PORTD->PCR[BOARD_LED_BLUE_GPIO_PIN] |= PORT_PCR_MUX(4);				//Blue TPM0_CH1, Mux Alt 4


	SIM->SCGC6 |= SIM_SCGC6_TPM0_MASK;									//enabling clock to TPM 0&2
	SIM->SCGC6 |= SIM_SCGC6_TPM2_MASK;

	SIM->SOPT2 |= (SIM_SOPT2_TPMSRC(1) | SIM_SOPT2_PLLFLLSEL_MASK);		//setting clock source for TPM: 48Mhz

	TPM0->MOD = MOD_VALUE;													//loading the counter and MOD register
	TPM2->MOD = MOD_VALUE;

	TPM0->SC =  TPM_SC_PS(1);											//setting prescalar=2
	TPM2->SC =  TPM_SC_PS(1);

	TPM0->CONF |= TPM_CONF_DBGMODE(3);									//continue operation in debug mode
	TPM2->CONF |= TPM_CONF_DBGMODE(3);

	TPM0->CONTROLS[1].CnSC = TPM_CnSC_MSB_MASK | TPM_CnSC_ELSA_MASK;	//setting time to edge-aligned low-true PWM
	TPM2->CONTROLS[0].CnSC = TPM_CnSC_MSB_MASK | TPM_CnSC_ELSA_MASK;
	TPM2->CONTROLS[1].CnSC = TPM_CnSC_MSB_MASK | TPM_CnSC_ELSA_MASK;

	TPM0->CONTROLS[1].CnV = 0;											//setting initial duty cycle
	TPM2->CONTROLS[0].CnV = 0;
	TPM2->CONTROLS[1].CnV = 0;

	TPM0->SC |= TPM_SC_CMOD(1);											//selecting LPTPM as clock source
	TPM2->SC |= TPM_SC_CMOD(1);
}


